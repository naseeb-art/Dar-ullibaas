# LAVENTURE — Technical Specification

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^18.2 | UI framework |
| react-dom | ^18.2 | React DOM renderer |
| typescript | ^5.3 | Type safety |
| vite | ^5.0 | Build tool / dev server |
| tailwindcss | ^3.4 | Utility-first CSS |
| postcss | ^8.4 | CSS processing |
| autoprefixer | ^10.4 | CSS vendor prefixes |
| @fontsource/playfair-display | ^5.0 | Display font (self-hosted) |
| @fontsource/inter | ^5.0 | Body font (self-hosted) |
| gsap | ^3.12 | Animation engine — ScrollTrigger, timeline sequences |
| lenis | ^1.0 | Smooth scrolling with inertia |
| swiper | ^11.0 | Touch carousels — arrivals, sale, fabrics |
| lucide-react | ^0.400 | Icon library (cart, arrows, phone, etc.) |
| clsx | ^2.0 | Conditional className joining |
| tailwind-merge | ^2.0 | Tailwind class conflict resolution |

---

## Component Inventory

### shadcn/ui Components

| Component | Source | Customization |
|-----------|--------|---------------|
| Sheet | `npx shadcn add sheet` | Used for Cart Sidebar (right-side drawer). Override: 420px width, custom animation, black border-left. |
| Badge | `npx shadcn add badge` | Used for pricing type labels ("Per Piece" / "Per Yard"), sale badges. Override: gold-accent and sale-red variants. |
| Button | `npx shadcn add button` | Base for all button variants. Override: remove border-radius (0px), add gold-dark hover, custom padding. |
| Toast | `npx shadcn add toast` | Used for "Added to cart" notifications. Override: bottom-left position, 3s duration. |

### Custom Components

| Component | Purpose | Props |
|-----------|---------|-------|
| **Navbar** | Fixed navigation bar with brand, links, cart icon | — |
| **AnnouncementBar** | Sticky rotating message bar with close button | messages: string[] |
| **CartSidebar** | Right-side cart drawer using shadcn Sheet | — |
| **ProductCard** | Reusable card with image, name, price, sale badge, add-to-cart | product: Product, onAddToCart: () => void |
| **QuantitySelector** | +/- stepper for per-piece, decimal input for per-yard | type: "piece" \| "yard", value: number, onChange: (v: number) => void |
| **LiveCountdown** | Days/hours/minutes/seconds timer with expiry state | endDate: Date |
| **Carousel** | Swiper wrapper with custom navigation arrows | children, slidesPerView, loop, autoplay? |
| **SectionNumber** | Decorative rotated counter text ("01", "02"...) | number: string, position: "left" \| "right" |
| **FilterBar** | Category pill filter buttons for collection section | categories: string[], active: string, onChange: (c: string) => void |
| **DecorativeX** | Thin X SVG icon for visual texture | size?: number, opacity?: number |
| **ScrollIndicator** | Bouncing chevron for hero section | visible: boolean |
| **Toast** | Inline toast notification (wraps shadcn toast) | — |

### Section Components

| Section | Key Features |
|---------|-------------|
| **HeroSection** | Full-viewport, scroll-pinned, GSAP scrub timeline (title scale/fade, bg zoom, panel translate) |
| **ArrivalsSection** | Swiper carousel, parallax section number, ScrollTrigger slide-in |
| **SaleSection** | Live countdown timer, 4-column product grid, featured banner, staggered card entrance |
| **FabricsSection** | Two-column split, per-yard pricing badges, auto-advancing Swiper slider |
| **CollectionSection** | FilterBar + ProductCard grid, dual pricing display, "Load More" button |
| **ContactSection** | Portrait parallax scale, 3 CTAs (tel, directions, WhatsApp), decorative X icons |
| **FooterSection** | Gold-dark background, brand wordmark, nav links, contact info, entrance animation |

---

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| **Hero scroll sequence** (pin + scrub timeline: title scale/fade, bg zoom, panel translate up) | GSAP ScrollTrigger | Pinned hero, scrubbed timeline over 150vh with 3 phases. | 🔒 High |
| **Arrivals carousel slide-in** | GSAP ScrollTrigger | `translateX: 100px → 0`, `opacity: 0 → 1`, scrub 0.5 | Medium |
| **Section number parallax** | GSAP ScrollTrigger | `translateY` at 0.4x scroll speed, scrub | Low |
| **Sale cards stagger** | GSAP ScrollTrigger | `opacity: 0, y: 40` → visible, stagger 0.15s, `start: "top 80%"` | Medium |
| **Sale banner slide-up** | GSAP ScrollTrigger | `y: 30px → 0`, `opacity: 0 → 1` | Low |
| **Fabrics slider slide-in** | GSAP ScrollTrigger | `translateX: 60px → 0`, scrub 0.5 | Medium |
| **Contact portrait scale** | GSAP ScrollTrigger | `scale: 0.9 → 1.0`, `opacity: 0 → 1`, scrub 0.5 | Low |
| **Decorative X drift** | GSAP ScrollTrigger | `translateY` at 0.3x scroll speed | Low |
| **Footer border scaleX** | GSAP ScrollTrigger | `scaleX: 0 → 1`, `transform-origin: left`, 0.6s | Low |
| **Standard scroll reveal** | GSAP ScrollTrigger | `opacity: 0, y: 40` → visible, 0.8s, `power3.out` | Low |
| **Product card hover** | CSS | `transform: scale(1.05)` on image, `opacity/translateY` on add button | Low |
| **Countdown number pulse** | CSS | `@keyframes` scale 1.0 → 0.95 → 1.0, 0.3s on tick | Low |
| **Announcement rotation** | CSS + React | `opacity/translateY` fade transition, 5s interval via `setInterval` | Low |
| **Scroll indicator bounce** | CSS | `@keyframes bounce`, 2s infinite | Low |
| **Cart sidebar slide** | CSS (shadcn Sheet) | `translateX: 100% → 0`, 0.4s `cubic-bezier(0.16, 1, 0.3, 1)` | Low |
| **Navbar border fade** | GSAP ScrollTrigger | `opacity: 0 → 0.1` on scroll past hero | Low |
| **Smooth scrolling** | Lenis | Lenis instance with `inertia: 0.1`, calls `ScrollTrigger.update()` each frame | Medium |

---

## State & Logic Plan

### Cart State Management

**Architecture**: React Context at app level (`CartContext` + `CartProvider`).

**State shape**:
```typescript
interface CartState {
  items: CartItem[];
  isOpen: boolean;
}
```

**Actions**: `addItem(product, quantity)`, `removeItem(itemId)`, `updateQuantity(itemId, quantity)`, `clearCart()`, `toggleCart()`, `setCartOpen(boolean)`.

**Side effects**: Persist to `localStorage` on every change. Derive `itemCount` (sum of quantities) and `subtotal` (sum of line totals) as memoized values.

**Toast integration**: `addItem` triggers a toast notification showing the added product name (3s, bottom-left).

### Product Data Model

Static product array typed as `Product[]`. Each product has `pricingType: "piece" | "yard"` and optional `salePrice` / `discount` fields. This drives conditional rendering in ProductCard (yard label, price display) and QuantitySelector (stepper vs decimal input).

### Filter Logic (Collection Section)

Local `useState` for active filter category. Filter product array with `Array.filter`. "All" shows everything. Categories: "Suits", "Shirts", "Outerwear", "Fabrics".

### Countdown Timer Logic

Component-local `useEffect` with `setInterval(1000)`. Calculate `endDate - now` on each tick. Format into days/hours/minutes/seconds. When difference ≤ 0, show expired state and clear interval. Cleanup interval on unmount.

### Announcement Rotation

Component-local `useState` for active index. `setInterval(5000)` to cycle through messages array. CSS transition (`opacity + translateY`) handles the visual crossfade.

### Reduced Motion Support

Global hook `useReducedMotion()` checks `prefers-reduced-motion` media query. All GSAP timelines and CSS animations are conditionally disabled — content shows immediately without motion.

---

## Other Key Decisions

### No Routing
Single-page website with anchor-based navigation (`#arrivals`, `#sale`, etc.). All content on one scrollable page. `lenis.scrollTo(target)` for smooth anchor scrolling.

### Image Asset Strategy
16 product/lifestyle images. All generated via AI image generation tool. Stored in `/public/images/`. Lazy-loaded via Swiper's built-in lazy loading and native `loading="lazy"` on static images.

### Swiper vs Custom Carousel
Swiper chosen for all three carousels (arrivals, sale, fabrics). It provides touch gestures, loop, autoplay, and responsive breakpoints out of the box. Custom GSAP carousel would require rebuilding touch handling — unnecessary complexity for this use case.

### shadcn Toast for Cart Notifications
Using shadcn's built-in `Toaster` component (positioned bottom-left) rather than building a custom toast system. The `toast()` function is called from the CartContext `addItem` action.

### Font Loading
Both Playfair Display and Inter loaded via `@fontsource` packages for self-hosting (no external CDN dependency). Imported at app entry point with specific weights (400 for Playfair, 400 + 500 for Inter).
