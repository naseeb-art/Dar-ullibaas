import type { Product } from "@/types";

export const products: Product[] = [
  // New Arrivals
  {
    id: "arr-1",
    name: "Camel Wool Overcoat",
    category: "Outerwear",
    pricingType: "piece",
    price: 1295,
    image: "/images/arrival-1.jpg",
    isNew: true,
  },
  {
    id: "arr-2",
    name: "Navy Cashmere Blazer",
    category: "Suits",
    pricingType: "piece",
    price: 1895,
    image: "/images/arrival-2.jpg",
    isNew: true,
  },
  {
    id: "arr-3",
    name: "Ivory Silk Blouse",
    category: "Shirts",
    pricingType: "piece",
    price: 695,
    image: "/images/arrival-3.jpg",
    isNew: true,
  },
  {
    id: "arr-4",
    name: "Charcoal Tailored Trousers",
    category: "Suits",
    pricingType: "piece",
    price: 595,
    image: "/images/arrival-4.jpg",
    isNew: true,
  },
  // Sale Products
  {
    id: "sale-1",
    name: "Burgundy Velvet Evening Jacket",
    category: "Outerwear",
    pricingType: "piece",
    price: 2495,
    salePrice: 1247,
    discount: 50,
    image: "/images/sale-1.jpg",
    isSale: true,
  },
  {
    id: "sale-2",
    name: "Cream Linen Summer Suit",
    category: "Suits",
    pricingType: "piece",
    price: 1895,
    salePrice: 948,
    discount: 50,
    image: "/images/sale-2.jpg",
    isSale: true,
  },
  {
    id: "sale-3",
    name: "Black Leather Belt",
    category: "Accessories",
    pricingType: "piece",
    price: 395,
    salePrice: 197,
    discount: 50,
    image: "/images/sale-3.jpg",
    isSale: true,
  },
  {
    id: "sale-4",
    name: "Olive Green Wool Scarf",
    category: "Accessories",
    pricingType: "piece",
    price: 295,
    salePrice: 148,
    discount: 50,
    image: "/images/sale-4.jpg",
    isSale: true,
  },
  // Fabrics (Per Yard)
  {
    id: "fab-1",
    name: "Italian Wool Twill — Charcoal",
    category: "Fabrics",
    pricingType: "yard",
    price: 185,
    image: "/images/fabric-1.jpg",
  },
  {
    id: "fab-2",
    name: "Silk Charmeuse — Champagne",
    category: "Fabrics",
    pricingType: "yard",
    price: 245,
    image: "/images/fabric-2.jpg",
  },
  {
    id: "fab-3",
    name: "Herringbone Tweed — Brown",
    category: "Fabrics",
    pricingType: "yard",
    price: 165,
    image: "/images/fabric-3.jpg",
  },
  // Collection (Per Piece)
  {
    id: "col-1",
    name: "Navy Pinstripe Three-Piece Suit",
    category: "Suits",
    pricingType: "piece",
    price: 3295,
    image: "/images/collection-suit-1.jpg",
  },
  {
    id: "col-2",
    name: "Egyptian Cotton Dress Shirt",
    category: "Shirts",
    pricingType: "piece",
    price: 425,
    image: "/images/collection-shirt-1.jpg",
  },
  // Collection (Per Yard Fabric)
  {
    id: "col-3",
    name: "Burgundy Velvet — By the Yard",
    category: "Fabrics",
    pricingType: "yard",
    price: 320,
    image: "/images/collection-fabric-1.jpg",
  },
];

export const newArrivals = products.filter((p) => p.isNew);
export const saleProducts = products.filter((p) => p.isSale);
export const fabricProducts = products.filter((p) => p.pricingType === "yard");

export const categories = ["All", "Suits", "Shirts", "Outerwear", "Fabrics"];
