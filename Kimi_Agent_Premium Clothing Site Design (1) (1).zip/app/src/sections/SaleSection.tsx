import { useRef, useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ProductCard } from "@/components/ProductCard";
import { LiveCountdown } from "@/components/LiveCountdown";
import { saleProducts } from "@/data/products";

gsap.registerPlugin(ScrollTrigger);

// Set sale end date to 14 days from now
const saleEndDate = new Date();
saleEndDate.setDate(saleEndDate.getDate() + 14);

export function SaleSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const bannerRef = useRef<HTMLDivElement>(null);
  const countdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const grid = gridRef.current;
    const banner = bannerRef.current;
    const countdown = countdownRef.current;
    if (!section || !heading || !grid || !banner || !countdown) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      gsap.set([heading, banner, countdown], { opacity: 1, y: 0 });
      gsap.set(grid.children, { opacity: 1, y: 0 });
      return;
    }

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.set(heading, { opacity: 0, y: 60 });
      gsap.to(heading, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 80%",
          end: "top 30%",
          scrub: 0.8,
        },
      });

      // Product cards stagger
      gsap.set(grid.children, { opacity: 0, y: 40 });
      gsap.to(grid.children, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.15,
        ease: "power3.out",
        scrollTrigger: {
          trigger: grid,
          start: "top 85%",
        },
      });

      // Countdown fade in last
      gsap.set(countdown, { opacity: 0, y: 20 });
      gsap.to(countdown, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        ease: "power3.out",
        scrollTrigger: {
          trigger: countdown,
          start: "top 90%",
        },
      });

      // Banner slide up
      gsap.set(banner, { opacity: 0, y: 30 });
      gsap.to(banner, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: banner,
          start: "top 90%",
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="sale"
      className="relative w-full bg-white border-t border-[var(--gold-accent)]"
      style={{ paddingTop: "clamp(4rem, 10vh, 8rem)", paddingBottom: "clamp(4rem, 10vh, 8rem)" }}
    >
      {/* Decorative X */}
      <div className="absolute top-8 right-8 text-[var(--gold-accent)] opacity-20 pointer-events-none">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
          <line x1="4" y1="4" x2="20" y2="20" />
          <line x1="20" y1="4" x2="4" y2="20" />
        </svg>
      </div>

      <div className="content-padding">
        {/* Section Header */}
        <div ref={headingRef} className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-12 gap-6 will-change-transform">
          <div>
            <h2
              className="font-display text-black"
              style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)" }}
            >
              Summer Sale
            </h2>
            <p className="text-sm text-[#999] font-body mt-2">
              Up to 50% off selected pieces
            </p>
          </div>
          <div ref={countdownRef} className="will-change-transform">
            <LiveCountdown endDate={saleEndDate} />
          </div>
        </div>

        {/* Product Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {saleProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* Featured Sale Banner */}
        <div
          ref={bannerRef}
          className="mt-12 bg-[var(--gold-accent)] p-8 sm:p-12 flex flex-col sm:flex-row items-center justify-between gap-6 will-change-transform"
        >
          <div className="sm:w-3/5">
            <h3
              className="font-display text-white"
              style={{ fontSize: "clamp(1.5rem, 3vw, 2rem)" }}
            >
              End of Season — Final Reductions
            </h3>
            <p className="text-sm text-white/80 font-body mt-2">
              Last chance to save up to 70% on archive pieces
            </p>
          </div>
          <button className="px-8 py-4 bg-white text-black text-sm font-medium font-body hover:bg-black hover:text-white transition-colors duration-300">
            Shop Final Reductions
          </button>
        </div>
      </div>
    </section>
  );
}
