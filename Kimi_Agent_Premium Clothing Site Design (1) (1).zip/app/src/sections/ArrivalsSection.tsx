import { useRef, useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Autoplay } from "swiper/modules";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { ProductCard } from "@/components/ProductCard";
import { newArrivals } from "@/data/products";
import "swiper/css";

gsap.registerPlugin(ScrollTrigger);

export function ArrivalsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const carouselRef = useRef<HTMLDivElement>(null);
  const numberRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const carousel = carouselRef.current;
    const number = numberRef.current;
    if (!section || !heading || !carousel || !number) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      gsap.set([heading, carousel], { opacity: 1, x: 0 });
      return;
    }

    const ctx = gsap.context(() => {
      gsap.set(carousel, { opacity: 0, x: 100 });
      gsap.set(heading, { opacity: 0, y: 40 });

      gsap.to(heading, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 85%",
        },
      });

      gsap.to(carousel, {
        opacity: 1,
        x: 0,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 75%",
          end: "bottom 50%",
          scrub: 0.5,
        },
      });

      // Section number parallax
      gsap.to(number, {
        y: -60,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top bottom",
          end: "bottom top",
          scrub: 0.5,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="arrivals"
      className="relative w-full bg-[var(--beige-bg)] overflow-hidden"
      style={{ paddingTop: "clamp(4rem, 10vh, 8rem)", paddingBottom: "4rem" }}
    >
      {/* Section Number */}
      <div
        ref={numberRef}
        className="absolute left-4 lg:left-8 top-1/2 -translate-y-1/2 pointer-events-none select-none will-change-transform"
      >
        <span
          className="font-display text-[4rem] text-[var(--beige-light)] opacity-30 block"
          style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
        >
          01
        </span>
      </div>

      <div className="content-padding">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-10 will-change-transform">
          <h2
            className="font-display text-black"
            style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)" }}
          >
            New Arrivals
          </h2>
          <p className="text-sm text-[#999] font-body mt-3">
            Discover our latest collection of refined essentials
          </p>
        </div>

        {/* Carousel */}
        <div ref={carouselRef} className="relative will-change-transform">
          <Swiper
            modules={[Navigation, Autoplay]}
            spaceBetween={24}
            loop={true}
            autoplay={{ delay: 4000, disableOnInteraction: false }}
            navigation={{
              prevEl: ".arrivals-prev",
              nextEl: ".arrivals-next",
            }}
            breakpoints={{
              320: { slidesPerView: 1.2 },
              640: { slidesPerView: 2.2 },
              1024: { slidesPerView: 3.6 },
            }}
            speed={600}
            className="!overflow-visible"
          >
            {newArrivals.map((product) => (
              <SwiperSlide key={product.id}>
                <ProductCard product={product} />
              </SwiperSlide>
            ))}
          </Swiper>

          {/* Custom Navigation */}
          <button className="arrivals-prev absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-12 h-12 rounded-full border border-black bg-transparent flex items-center justify-center hover:bg-black hover:text-white transition-all duration-300">
            <ChevronLeft size={20} />
          </button>
          <button className="arrivals-next absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-12 h-12 rounded-full border border-black bg-transparent flex items-center justify-center hover:bg-black hover:text-white transition-all duration-300">
            <ChevronRight size={20} />
          </button>
        </div>

        {/* Footer CTA */}
        <div className="text-center mt-10">
          <a
            href="#collection"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector("#collection")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="inline-flex items-center gap-2 text-sm text-black font-body hover:text-[var(--gold-accent)] transition-colors duration-300"
          >
            View All Arrivals
            <ArrowRight size={16} />
          </a>
        </div>
      </div>
    </section>
  );
}
