import { useRef, useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const navLinks = [
  { label: "Arrivals", href: "#arrivals" },
  { label: "Sale", href: "#sale" },
  { label: "Fabrics", href: "#fabrics" },
  { label: "Collection", href: "#collection" },
  { label: "Contact", href: "#contact" },
];

export function FooterSection() {
  const footerRef = useRef<HTMLElement>(null);
  const border1Ref = useRef<HTMLDivElement>(null);
  const border2Ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const footer = footerRef.current;
    const border1 = border1Ref.current;
    const border2 = border2Ref.current;
    if (!footer || !border1 || !border2) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      gsap.set([border1, border2], { scaleX: 1 });
      return;
    }

    const ctx = gsap.context(() => {
      gsap.set([border1, border2], { scaleX: 0, transformOrigin: "left" });

      gsap.to(border1, {
        scaleX: 1,
        duration: 0.6,
        ease: "power2.out",
        scrollTrigger: { trigger: footer, start: "top 90%" },
      });

      gsap.to(border2, {
        scaleX: 1,
        duration: 0.6,
        ease: "power2.out",
        delay: 0.2,
        scrollTrigger: { trigger: footer, start: "top 90%" },
      });
    }, footer);

    return () => ctx.revert();
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer ref={footerRef} className="w-full bg-[var(--gold-dark)]">
      <div className="content-padding pt-16 pb-8">
        {/* Top Row */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <a
            href="#top"
            onClick={(e) => handleNavClick(e, "#top")}
            className="font-display text-2xl text-white tracking-[0.1em]"
          >
            LAVENTURE
          </a>

          <div className="flex flex-wrap gap-6">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-sm text-white/60 font-body hover:text-white transition-colors duration-300"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>

        {/* Middle Row */}
        <div
          ref={border1Ref}
          className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between gap-8 will-change-transform"
        >
          <div>
            <p className="text-xs text-white/40 font-body">
              48 W 57th Street, New York, NY 10019
            </p>
            <p className="text-xs text-white/40 font-body mt-1">
              Open Tue–Sat, 10am–7pm
            </p>
          </div>

          <div className="flex flex-col sm:items-center">
            <a
              href="tel:+12125550176"
              className="text-xs text-white/60 font-body hover:text-white transition-colors duration-300"
            >
              +1 (212) 555-0176
            </a>
            <a
              href="mailto:hello@laventure.com"
              className="text-xs text-white/60 font-body hover:text-white transition-colors duration-300 mt-1"
            >
              hello@laventure.com
            </a>
          </div>

          <div className="flex gap-6 sm:justify-end">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-white/60 font-body hover:text-white transition-colors duration-300"
            >
              Instagram
            </a>
            <a
              href="https://pinterest.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-white/60 font-body hover:text-white transition-colors duration-300"
            >
              Pinterest
            </a>
          </div>
        </div>

        {/* Bottom Row */}
        <div
          ref={border2Ref}
          className="mt-12 pt-8 border-t border-white/10 text-center will-change-transform"
        >
          <p className="text-xs text-white/30 font-body">
            &copy; 2026 LAVENTURE. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
