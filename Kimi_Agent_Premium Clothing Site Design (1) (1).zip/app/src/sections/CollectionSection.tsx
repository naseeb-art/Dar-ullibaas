import { useState, useRef, useEffect, useMemo } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ProductCard } from "@/components/ProductCard";
import { products, categories } from "@/data/products";

gsap.registerPlugin(ScrollTrigger);

export function CollectionSection() {
  const [activeFilter, setActiveFilter] = useState("All");
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const filterRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  const filteredProducts = useMemo(() => {
    if (activeFilter === "All") return products;
    return products.filter((p) => p.category === activeFilter);
  }, [activeFilter]);

  useEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const filter = filterRef.current;
    const grid = gridRef.current;
    if (!section || !heading || !filter || !grid) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      gsap.set([heading, filter], { opacity: 1, y: 0 });
      gsap.set(grid.children, { opacity: 1, y: 0 });
      return;
    }

    const ctx = gsap.context(() => {
      gsap.set(heading, { opacity: 0, y: 40 });
      gsap.set(filter, { opacity: 0, y: 30 });

      gsap.to(heading, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: { trigger: section, start: "top 85%" },
      });

      gsap.to(filter, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        ease: "power3.out",
        delay: 0.1,
        scrollTrigger: { trigger: section, start: "top 85%" },
      });

      // Grid cards stagger
      gsap.set(grid.children, { opacity: 0, y: 30 });
      ScrollTrigger.create({
        trigger: grid,
        start: "top 85%",
        onEnter: () => {
          gsap.to(grid.children, {
            opacity: 1,
            y: 0,
            duration: 0.6,
            stagger: 0.1,
            ease: "power3.out",
          });
        },
        once: true,
      });
    }, section);

    return () => ctx.revert();
  }, []);

  // Re-animate grid when filter changes
  useEffect(() => {
    const grid = gridRef.current;
    if (!grid) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) return;

    gsap.fromTo(
      grid.children,
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.4, stagger: 0.08, ease: "power3.out" }
    );
  }, [activeFilter]);

  return (
    <section
      ref={sectionRef}
      id="collection"
      className="relative w-full bg-[var(--beige-bg)]"
      style={{ paddingTop: "clamp(4rem, 10vh, 8rem)", paddingBottom: "clamp(4rem, 10vh, 8rem)" }}
    >
      <div className="content-padding">
        {/* Heading */}
        <div ref={headingRef} className="text-center will-change-transform">
          <h2
            className="font-display text-black"
            style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)" }}
          >
            The Collection
          </h2>
        </div>

        {/* Filter Bar */}
        <div
          ref={filterRef}
          className="flex flex-wrap items-center justify-center gap-2 mt-8 mb-12 will-change-transform"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`px-5 py-2 text-xs font-medium font-body rounded-sm border transition-all duration-300 ${
                activeFilter === cat
                  ? "bg-black text-white border-black"
                  : "bg-transparent text-black border-black/10 hover:border-black"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <button className="px-8 py-4 border border-black text-sm font-medium font-body hover:bg-black hover:text-white transition-all duration-300">
            Load More
          </button>
        </div>
      </div>
    </section>
  );
}
