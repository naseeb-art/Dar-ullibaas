import { useRef, useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import { fabricProducts } from "@/data/products";
import "swiper/css";

gsap.registerPlugin(ScrollTrigger);

export function FabricsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const numberRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const left = leftRef.current;
    const right = rightRef.current;
    const number = numberRef.current;
    if (!section || !left || !right || !number) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      gsap.set([left, right], { opacity: 1, x: 0 });
      return;
    }

    const ctx = gsap.context(() => {
      // Left content staggered reveal
      const leftChildren = left.children;
      gsap.set(leftChildren, { opacity: 0, y: 30 });
      gsap.to(leftChildren, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.12,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 75%",
        },
      });

      // Right slider slide-in
      gsap.set(right, { opacity: 0, x: 60 });
      gsap.to(right, {
        opacity: 1,
        x: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 70%",
          end: "bottom 50%",
          scrub: 0.5,
        },
      });

      // Section number parallax
      gsap.to(number, {
        y: -40,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top bottom",
          end: "bottom top",
          scrub: 0.5,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="fabrics"
      className="relative w-full bg-[var(--beige-light)] overflow-hidden"
      style={{ paddingTop: "clamp(4rem, 10vh, 8rem)", paddingBottom: "clamp(4rem, 10vh, 8rem)" }}
    >
      {/* Section Number */}
      <div
        ref={numberRef}
        className="absolute right-4 lg:right-8 top-1/2 -translate-y-1/2 pointer-events-none select-none will-change-transform"
      >
        <span
          className="font-display text-[4rem] text-[var(--beige-bg)] opacity-30 block"
          style={{ writingMode: "vertical-rl" }}
        >
          03
        </span>
      </div>

      <div className="content-padding">
        <div className="flex flex-col lg:flex-row gap-10 lg:gap-16 items-center">
          {/* Left Column - Text */}
          <div ref={leftRef} className="lg:w-[45%] will-change-transform">
            <h2
              className="font-display text-black"
              style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)" }}
            >
              Premium Fabrics
            </h2>
            <p className="text-sm text-black/70 font-body mt-3">
              Italian wool, silk blends, and artisan textiles — by the yard
            </p>
            <p className="text-sm text-black/50 font-body mt-5 max-w-[420px] leading-relaxed">
              Hand-selected materials sourced from the finest European mills.
              Available by continuous yard for bespoke tailoring and personal projects.
            </p>
            <a
              href="#collection"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector("#collection")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="inline-block mt-8 px-8 py-4 bg-black text-white text-sm font-medium font-body hover:bg-[var(--gold-dark)] transition-colors duration-300"
            >
              Explore Fabrics
            </a>
          </div>

          {/* Right Column - Slider */}
          <div ref={rightRef} className="lg:w-[55%] w-full will-change-transform">
            <Swiper
              modules={[Autoplay]}
              spaceBetween={16}
              slidesPerView={1.5}
              breakpoints={{
                480: { slidesPerView: 2 },
                768: { slidesPerView: 2.5 },
              }}
              autoplay={{ delay: 4000, disableOnInteraction: false, pauseOnMouseEnter: true }}
              loop={true}
              speed={600}
              className="!overflow-visible"
            >
              {fabricProducts.map((fabric) => (
                <SwiperSlide key={fabric.id}>
                  <div className="relative group">
                    <div className="aspect-[4/3] overflow-hidden rounded-sm">
                      <img
                        src={fabric.image}
                        alt={fabric.name}
                        loading="lazy"
                        className="w-full h-full object-cover transition-transform duration-600 group-hover:scale-105"
                      />
                    </div>
                    <div className="mt-3">
                      <h4 className="text-sm font-medium text-black font-body truncate">
                        {fabric.name}
                      </h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm font-medium text-black font-body">
                          ${fabric.price}/yard
                        </span>
                        <span className="text-[10px] bg-[var(--gold-accent)] text-black px-2 py-0.5 font-body">
                          PER YARD
                        </span>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>
      </div>
    </section>
  );
}
