import { useRef, useEffect, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ChevronDown } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

export function HeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const bgRef = useRef<HTMLImageElement>(null);
  const indicatorRef = useRef<HTMLDivElement>(null);
  const [indicatorVisible, setIndicatorVisible] = useState(true);

  useEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const subtitle = subtitleRef.current;
    const bg = bgRef.current;
    const indicator = indicatorRef.current;
    if (!section || !title || !subtitle || !bg || !indicator) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      gsap.set([title, subtitle], { opacity: 1, y: 0 });
      gsap.set(bg, { scale: 1 });
      return;
    }

    const ctx = gsap.context(() => {
      // Initial states
      gsap.set(title, { opacity: 0, scale: 0.9 });
      gsap.set(subtitle, { opacity: 0, y: 20 });
      gsap.set(bg, { scale: 1.1 });

      // Create timeline
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: "top top",
          end: "+=150%",
          scrub: 0.5,
          pin: true,
          onUpdate: (self) => {
            setIndicatorVisible(self.progress < 0.15);
          },
        },
      });

      // Phase 1: Reveal (0% - 40%)
      tl.to(title, { opacity: 1, scale: 1, duration: 0.4, ease: "power2.out" }, 0);
      tl.to(subtitle, { opacity: 1, y: 0, duration: 0.3, ease: "power2.out" }, 0.1);
      tl.to(bg, { scale: 1, duration: 0.4, ease: "none" }, 0);

      // Phase 2: Fade out (40% - 100%)
      tl.to(title, { opacity: 0, y: -60, duration: 0.4, ease: "power2.in" }, 0.4);
      tl.to(subtitle, { opacity: 0, y: -40, duration: 0.35, ease: "power2.in" }, 0.42);
      tl.to(bg, { y: "-10%", duration: 0.5, ease: "none" }, 0.5);

      // Scroll indicator fade on scroll
      ScrollTrigger.create({
        trigger: section,
        start: "top top",
        end: "+=100px",
        onLeave: () => gsap.to(indicator, { opacity: 0, duration: 0.3 }),
        onEnterBack: () => gsap.to(indicator, { opacity: 1, duration: 0.3 }),
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="top"
      className="relative w-full h-screen overflow-hidden"
    >
      {/* Background Image */}
      <img
        ref={bgRef}
        src="/images/hero-bg.jpg"
        alt="LAVENTURE fashion"
        className="absolute inset-0 w-full h-full object-cover will-change-transform"
      />

      {/* Overlay for text readability */}
      <div className="absolute inset-0 bg-black/20" />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
        <h1
          ref={titleRef}
          className="font-display text-white text-center will-change-transform"
          style={{
            fontSize: "clamp(2.5rem, 6vw, 4.5rem)",
            textShadow: "0 2px 40px rgba(0,0,0,0.3)",
          }}
        >
          LAVENTURE
        </h1>
        <p
          ref={subtitleRef}
          className="text-white/80 text-sm sm:text-base font-body mt-4 tracking-wide text-center will-change-transform"
          style={{ textShadow: "0 1px 20px rgba(0,0,0,0.3)" }}
        >
          Crafted Elegance. Timeless Design.
        </p>
      </div>

      {/* Scroll Indicator */}
      <div
        ref={indicatorRef}
        className={`absolute bottom-8 left-1/2 -translate-x-1/2 z-10 transition-opacity duration-300 ${
          indicatorVisible ? "opacity-60" : "opacity-0"
        }`}
      >
        <ChevronDown size={24} className="text-white animate-bounce-scroll" />
      </div>
    </section>
  );
}
