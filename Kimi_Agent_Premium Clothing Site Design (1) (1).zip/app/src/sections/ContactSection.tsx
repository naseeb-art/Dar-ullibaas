import { useRef, useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Phone, MapPin, MessageCircle } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

export function ContactSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const x1Ref = useRef<HTMLDivElement>(null);
  const x2Ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const text = textRef.current;
    const x1 = x1Ref.current;
    const x2 = x2Ref.current;
    if (!section || !image || !text || !x1 || !x2) return;

    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) {
      gsap.set([image, text], { opacity: 1, scale: 1, x: 0 });
      return;
    }

    const ctx = gsap.context(() => {
      // Portrait image scale animation
      gsap.set(image, { opacity: 0, scale: 0.9 });
      gsap.to(image, {
        opacity: 1,
        scale: 1,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 75%",
          end: "center center",
          scrub: 0.5,
        },
      });

      // Text content staggered reveal
      const textChildren = text.children;
      gsap.set(textChildren, { opacity: 0, y: 30 });
      gsap.to(textChildren, {
        opacity: 1,
        y: 0,
        duration: 0.6,
        stagger: 0.2,
        ease: "power3.out",
        scrollTrigger: {
          trigger: text,
          start: "top 85%",
        },
      });

      // Decorative X icons drift
      gsap.to([x1, x2], {
        y: -30,
        ease: "none",
        scrollTrigger: {
          trigger: section,
          start: "top bottom",
          end: "bottom top",
          scrub: 0.5,
        },
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative w-full bg-[var(--beige-bg)] overflow-hidden"
      style={{ paddingTop: "clamp(4rem, 10vh, 8rem)", paddingBottom: "clamp(4rem, 10vh, 8rem)" }}
    >
      {/* Section Number */}
      <div className="absolute left-4 lg:left-8 top-1/2 -translate-y-1/2 pointer-events-none select-none">
        <span
          className="font-display text-[4rem] text-[var(--beige-light)] opacity-30 block"
          style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
        >
          05
        </span>
      </div>

      <div className="content-padding max-w-[1200px] mx-auto">
        <div className="flex flex-col md:flex-row gap-8 lg:gap-16 items-center">
          {/* Left — Portrait Image */}
          <div className="md:w-1/2 relative">
            {/* Decorative X icons */}
            <div
              ref={x1Ref}
              className="absolute -top-5 -left-5 text-[var(--beige-light)] pointer-events-none will-change-transform"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1">
                <line x1="4" y1="4" x2="16" y2="16" />
                <line x1="16" y1="4" x2="4" y2="16" />
              </svg>
            </div>
            <div
              ref={x2Ref}
              className="absolute -bottom-5 right-8 text-[var(--beige-light)] pointer-events-none will-change-transform"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1">
                <line x1="4" y1="4" x2="16" y2="16" />
                <line x1="16" y1="4" x2="4" y2="16" />
              </svg>
            </div>

            <div
              ref={imageRef}
              className="overflow-hidden rounded-sm will-change-transform"
              style={{ maxHeight: "70vh" }}
            >
              <img
                src="/images/contact-portrait.jpg"
                alt="Fashion designer at work"
                className="w-full h-full object-cover"
                style={{ aspectRatio: "2/3" }}
              />
            </div>
          </div>

          {/* Right — Text Content */}
          <div ref={textRef} className="md:w-1/2 will-change-transform">
            <h2
              className="font-display text-black"
              style={{ fontSize: "clamp(1.75rem, 4vw, 3rem)" }}
            >
              Experience LAVENTURE
            </h2>
            <p className="text-sm text-black/70 font-body mt-6 max-w-[400px] leading-relaxed">
              Visit our flagship atelier for a personal consultation. Our craftsmen
              are ready to bring your vision to life.
            </p>

            {/* Call Button */}
            <a
              href="tel:+12125550176"
              className="inline-flex items-center gap-3 mt-8 px-8 py-4 bg-black text-white text-sm font-medium font-body hover:bg-[var(--gold-dark)] transition-colors duration-300"
            >
              <Phone size={16} />
              Call: +1 (212) 555-0176
            </a>

            {/* Get Directions */}
            <a
              href="https://maps.google.com/?q=48+W+57th+Street+New+York+NY+10019"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 mt-4 text-sm text-black font-body hover:text-[var(--gold-accent)] transition-colors duration-300"
            >
              <MapPin size={16} />
              Get Directions
            </a>

            {/* WhatsApp */}
            <a
              href="https://wa.me/12125550176"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 mt-3 text-sm text-black font-body hover:text-[#25D366] transition-colors duration-300"
            >
              <MessageCircle size={16} />
              Message on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
