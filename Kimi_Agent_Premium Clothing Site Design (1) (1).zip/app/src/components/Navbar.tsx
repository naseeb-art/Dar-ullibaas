import { useState, useEffect } from "react";
import { ShoppingBag, Menu, X } from "lucide-react";
import { useCart } from "@/context/CartContext";

const navLinks = [
  { label: "Arrivals", href: "#arrivals" },
  { label: "Sale", href: "#sale" },
  { label: "Fabrics", href: "#fabrics" },
  { label: "Collection", href: "#collection" },
  { label: "Contact", href: "#contact" },
];

export function Navbar() {
  const { itemCount, toggleCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={`fixed left-0 right-0 z-[1000] h-[72px] flex items-center transition-all duration-300 ${
        scrolled ? "border-b border-black/10" : ""
      }`}
      style={{
        top: "var(--announcement-offset, 40px)",
        backgroundColor: "rgba(246, 239, 232, 0.8)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
      }}
    >
      <div className="w-full flex items-center justify-between px-6 lg:px-10">
        {/* Brand */}
        <a
          href="#top"
          onClick={(e) => handleNavClick(e, "#top")}
          className="font-display text-xl text-black tracking-[0.08em]"
        >
          LAVENTURE
        </a>

        {/* Center Nav — Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="text-sm font-medium text-black hover:text-[var(--gold-accent)] transition-colors duration-300 font-body tracking-wide"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Right — Cart + Mobile Menu */}
        <div className="flex items-center gap-4">
          <button
            onClick={toggleCart}
            className="relative p-2 hover:text-[var(--gold-accent)] transition-colors duration-300"
            aria-label="Open cart"
          >
            <ShoppingBag size={22} strokeWidth={1.5} />
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-[var(--gold-accent)] text-white text-[10px] font-medium rounded-full flex items-center justify-center">
              {itemCount}
            </span>
          </button>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="absolute top-[72px] left-0 right-0 bg-[var(--beige-bg)] border-b border-black/10 md:hidden">
          <div className="flex flex-col py-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-6 py-3 text-sm font-medium text-black hover:text-[var(--gold-accent)] transition-colors font-body"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
