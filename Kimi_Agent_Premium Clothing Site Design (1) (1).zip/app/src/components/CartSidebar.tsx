import { Plus, Minus, Trash2, ShoppingBag } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useCart } from "@/context/CartContext";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export function CartSidebar() {
  const { state, setCartOpen, removeItem, updateQuantity, subtotal, clearCart } = useCart();

  const handleCheckout = () => {
    if (state.items.length === 0) return;
    toast.success("Proceeding to checkout...", { duration: 3000 });
    clearCart();
    setCartOpen(false);
  };

  return (
    <Sheet open={state.isOpen} onOpenChange={setCartOpen}>
      <SheetContent className="w-full sm:w-[420px] p-0 flex flex-col bg-white border-l border-black/10">
        <SheetHeader className="px-6 py-5 border-b border-black/10">
          <SheetTitle className="font-display text-lg tracking-wide">Your Cart</SheetTitle>
        </SheetHeader>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {state.items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingBag size={48} className="text-[#ddd] mb-4" />
              <p className="text-sm text-[#999] font-body mb-4">Your cart is empty</p>
              <button
                onClick={() => setCartOpen(false)}
                className="text-sm text-[var(--gold-accent)] hover:text-[var(--gold-dark)] font-body underline"
              >
                Browse Collection
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {state.items.map((item) => {
                const price = item.product.salePrice ?? item.product.price;
                const lineTotal = price * item.quantity;

                return (
                  <div
                    key={item.product.id}
                    className="flex gap-4 p-3 bg-[var(--beige-bg)]/50 rounded-sm"
                  >
                    {/* Thumbnail */}
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                    />

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-sm font-medium text-black font-body truncate">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => removeItem(item.product.id)}
                          className="text-[#999] hover:text-[var(--sale-red)] transition-colors flex-shrink-0"
                          aria-label="Remove item"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>

                      <Badge
                        variant="secondary"
                        className="mt-1 text-[10px] bg-[var(--gold-accent)] text-black hover:bg-[var(--gold-accent)]"
                      >
                        {item.product.pricingType === "yard" ? "Per Yard" : "Per Piece"}
                      </Badge>

                      {/* Quantity Controls */}
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              updateQuantity(
                                item.product.id,
                                item.quantity -
                                  (item.product.pricingType === "yard" ? 0.5 : 1)
                              )
                            }
                            className="w-6 h-6 flex items-center justify-center border border-black/20 rounded-sm hover:bg-black hover:text-white transition-colors"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="text-sm font-medium w-12 text-center font-body">
                            {item.product.pricingType === "yard"
                              ? item.quantity.toFixed(1)
                              : item.quantity}
                            {item.product.pricingType === "yard" && (
                              <span className="text-xs text-[#999]">yd</span>
                            )}
                          </span>
                          <button
                            onClick={() =>
                              updateQuantity(
                                item.product.id,
                                item.quantity +
                                  (item.product.pricingType === "yard" ? 0.5 : 1)
                              )
                            }
                            className="w-6 h-6 flex items-center justify-center border border-black/20 rounded-sm hover:bg-black hover:text-white transition-colors"
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        <span className="text-sm font-medium font-body">
                          ${lineTotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
                        </span>
                      </div>

                      <p className="text-xs text-[#999] mt-1 font-body">
                        ${price.toLocaleString()}
                        {item.product.pricingType === "yard" ? "/yard" : "/pc"} ×{" "}
                        {item.product.pricingType === "yard"
                          ? item.quantity.toFixed(1)
                          : item.quantity}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        {state.items.length > 0 && (
          <div className="border-t border-black/10 px-6 py-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-[#999] font-body">Subtotal</span>
              <span className="text-xl font-display">
                ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
              </span>
            </div>
            <button
              onClick={handleCheckout}
              className="w-full py-4 bg-black text-white text-sm font-medium font-body hover:bg-[var(--gold-dark)] transition-colors duration-300"
            >
              Checkout
            </button>
            <button
              onClick={() => setCartOpen(false)}
              className="w-full text-center text-xs text-[var(--gold-accent)] hover:text-[var(--gold-dark)] font-body"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
