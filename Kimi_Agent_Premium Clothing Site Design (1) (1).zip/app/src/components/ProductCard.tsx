import { useState } from "react";
import { Plus } from "lucide-react";
import type { Product } from "@/types";
import { useCart } from "@/context/CartContext";
import { toast } from "sonner";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const [isHovered, setIsHovered] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);

  const hasDiscount = product.discount && product.discount > 0;

  const handleAddToCart = () => {
    const qty = product.pricingType === "yard" ? 1 : 1;
    addItem(product, qty);
    toast.success(`${product.name} added to cart`, {
      position: "bottom-left",
      duration: 3000,
    });
  };

  return (
    <article
      className="group bg-white border border-black/[0.06] rounded-sm overflow-hidden will-change-transform"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Area */}
      <div className="relative aspect-square overflow-hidden">
        {!imgLoaded && (
          <div className="absolute inset-0 bg-[var(--beige-light)] animate-pulse" />
        )}
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          onLoad={() => setImgLoaded(true)}
          className={`w-full h-full object-cover transition-transform duration-600 ease-out ${
            isHovered ? "scale-105" : "scale-100"
          } ${imgLoaded ? "opacity-100" : "opacity-0"}`}
          style={{ transitionDuration: "600ms" }}
        />

        {/* Sale Badge */}
        {hasDiscount && (
          <div className="absolute top-3 left-3 bg-[var(--sale-red)] text-white text-xs font-medium px-3 py-1">
            {product.discount}% OFF
          </div>
        )}

        {/* New Badge */}
        {product.isNew && !hasDiscount && (
          <div className="absolute top-3 left-3 bg-black text-white text-xs font-medium px-3 py-1">
            NEW
          </div>
        )}

        {/* Per Yard Badge */}
        {product.pricingType === "yard" && (
          <div className="absolute top-3 right-3 bg-[var(--gold-accent)] text-black text-xs font-medium px-3 py-1">
            PER YARD
          </div>
        )}

        {/* Add to Cart Button (hover) */}
        <div
          className={`absolute bottom-3 right-3 transition-all duration-300 ${
            isHovered ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
          }`}
        >
          <button
            onClick={handleAddToCart}
            className="w-10 h-10 bg-black text-white rounded-full flex items-center justify-center hover:bg-[var(--gold-accent)] transition-colors duration-300"
            aria-label={`Add ${product.name} to cart`}
          >
            <Plus size={18} />
          </button>
        </div>
      </div>

      {/* Info Area */}
      <div className="p-4">
        <p className="text-xs text-[#999] mb-1 font-body">{product.category}</p>
        <h3 className="text-sm font-medium text-black truncate font-body">
          {product.name}
        </h3>
        <div className="flex items-center gap-2 mt-2">
          {hasDiscount && product.salePrice ? (
            <>
              <span className="text-sm font-medium text-[var(--sale-red)] font-body">
                ${product.salePrice.toLocaleString()}
              </span>
              <span className="text-xs text-[#999] line-through font-body">
                ${product.price.toLocaleString()}
              </span>
            </>
          ) : (
            <span className="text-sm font-medium text-black font-body">
              ${product.price.toLocaleString()}
              {product.pricingType === "yard" && (
                <span className="text-xs text-[#999] ml-1">/ yard</span>
              )}
            </span>
          )}
        </div>
      </div>
    </article>
  );
}
