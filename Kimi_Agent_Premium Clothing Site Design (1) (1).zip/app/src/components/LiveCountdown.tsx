import { useState, useEffect } from "react";

interface LiveCountdownProps {
  endDate: Date;
}

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

function calculateTimeLeft(target: Date): TimeLeft | null {
  const diff = target.getTime() - Date.now();
  if (diff <= 0) return null;

  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

export function LiveCountdown({ endDate }: LiveCountdownProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(calculateTimeLeft(endDate));
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      const remaining = calculateTimeLeft(endDate);
      setTimeLeft(remaining);
      setTick((t) => t + 1);
      if (!remaining) clearInterval(timer);
    }, 1000);

    return () => clearInterval(timer);
  }, [endDate]);

  if (!timeLeft) {
    return (
      <div className="text-[var(--sale-red)] text-sm font-medium font-body line-through">
        Sale Ended
      </div>
    );
  }

  const units = [
    { value: timeLeft.days, label: "Days" },
    { value: timeLeft.hours, label: "Hrs" },
    { value: timeLeft.minutes, label: "Min" },
    { value: timeLeft.seconds, label: "Sec" },
  ];

  return (
    <div className="flex items-center gap-1" aria-live="polite">
      {units.map((unit, i) => (
        <div key={unit.label} className="flex items-center gap-1">
          <div
            className={`w-14 h-14 sm:w-16 sm:h-16 bg-white border border-[var(--gold-accent)] rounded-sm flex flex-col items-center justify-center ${
              unit.label === "Sec" ? "animate-countdown-pulse" : ""
            }`}
            style={unit.label === "Sec" ? { animationDelay: `${tick * 1000}ms` } : {}}
          >
            <span className="font-display text-lg sm:text-2xl text-black leading-none">
              {String(unit.value).padStart(2, "0")}
            </span>
            <span className="text-[10px] text-[#999] font-body mt-0.5">{unit.label}</span>
          </div>
          {i < units.length - 1 && (
            <span className="text-[var(--gold-accent)] font-display text-lg mx-0.5">:</span>
          )}
        </div>
      ))}
    </div>
  );
}
