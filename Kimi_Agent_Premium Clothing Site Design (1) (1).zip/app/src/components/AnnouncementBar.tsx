import { useState, useEffect, useCallback } from "react";
import { X } from "lucide-react";

const messages = [
  "Free shipping on orders over $500",
  "Summer Sale — Up to 50% OFF",
  "Premium Fabrics — New Collection In-Store",
];

export function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const rotateMessage = useCallback(() => {
    setIsAnimating(true);
    setTimeout(() => {
      setActiveIndex((prev) => (prev + 1) % messages.length);
      setIsAnimating(false);
    }, 400);
  }, []);

  useEffect(() => {
    const interval = setInterval(rotateMessage, 5000);
    return () => clearInterval(interval);
  }, [rotateMessage]);

  if (!isVisible) return null;

  return (
    <div
      className="fixed top-0 left-0 right-0 h-10 bg-black flex items-center justify-center z-[1001] transition-all duration-300"
      aria-live="polite"
    >
      <div className="relative h-full flex items-center justify-center overflow-hidden px-12">
        <span
          className={`text-white text-xs tracking-widest font-body transition-all duration-400 ${
            isAnimating ? "opacity-0 translate-y-2" : "opacity-100 translate-y-0"
          }`}
        >
          {messages[activeIndex]}
        </span>
      </div>
      <button
        onClick={() => setIsVisible(false)}
        className="absolute right-4 text-white/60 hover:text-white transition-colors duration-200"
        aria-label="Close announcement bar"
      >
        <X size={14} />
      </button>
    </div>
  );
}
