import { useEffect, useRef } from "react";
import Lenis from "lenis";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Toaster } from "sonner";
import { CartProvider } from "@/context/CartContext";
import { AnnouncementBar } from "@/components/AnnouncementBar";
import { Navbar } from "@/components/Navbar";
import { CartSidebar } from "@/components/CartSidebar";
import { HeroSection } from "@/sections/HeroSection";
import { ArrivalsSection } from "@/sections/ArrivalsSection";
import { SaleSection } from "@/sections/SaleSection";
import { FabricsSection } from "@/sections/FabricsSection";
import { CollectionSection } from "@/sections/CollectionSection";
import { ContactSection } from "@/sections/ContactSection";
import { FooterSection } from "@/sections/FooterSection";

gsap.registerPlugin(ScrollTrigger);

function SmoothScrollProvider({ children }: { children: React.ReactNode }) {
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      touchMultiplier: 2,
    });
    lenisRef.current = lenis;

    lenis.on("scroll", ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });
    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
    };
  }, []);

  return <>{children}</>;
}

function AppContent() {
  useEffect(() => {
    // Set CSS variable for navbar offset (announcement bar is 40px)
    document.documentElement.style.setProperty("--announcement-offset", "40px");
  }, []);

  return (
    <div className="relative">
      <AnnouncementBar />
      <Navbar />
      <CartSidebar />
      <Toaster
        position="bottom-left"
        toastOptions={{
          style: {
            background: "#000",
            color: "#fff",
            border: "none",
            fontFamily: "var(--font-body)",
            fontSize: "13px",
          },
        }}
      />
      <main>
        <HeroSection />
        <ArrivalsSection />
        <SaleSection />
        <FabricsSection />
        <CollectionSection />
        <ContactSection />
      </main>
      <FooterSection />
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <SmoothScrollProvider>
        <AppContent />
      </SmoothScrollProvider>
    </CartProvider>
  );
}
