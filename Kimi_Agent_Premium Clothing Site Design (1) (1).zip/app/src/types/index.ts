export interface Product {
  id: string;
  name: string;
  category: string;
  pricingType: "piece" | "yard";
  price: number;
  salePrice?: number;
  discount?: number;
  image: string;
  isNew?: boolean;
  isSale?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface CartState {
  items: CartItem[];
  isOpen: boolean;
}
